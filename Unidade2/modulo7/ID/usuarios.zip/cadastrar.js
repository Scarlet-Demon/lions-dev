

function cadastrarUsuario(usuarios, usuário) {
    usuarios.push(usuário)
}
module.exports = cadastrarUsuario