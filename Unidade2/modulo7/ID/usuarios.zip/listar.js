const usuarios = require("./usuarios");

function listarUsuarios() {
    if (residencias.length == 0) { 
        console.log('Não A Moradores Cadastrados')
        callback()
    } else {
        residencias.forEach((usuario) => {
            console.log(`ID: ${usuario.id}, Nome: ${usuario.nome}, Email: ${usuario.email}, Telefone: ${usuario.telefone}`)
        });
    }
}
module.exports = listarUsuarios