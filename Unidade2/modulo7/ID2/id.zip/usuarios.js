module.exports = [
    {
    id: 1,
    nome: 'Leonardo',
    telefones: ['8765-4321', '1232-3421'],
    email: 'leonardo@hotmail.com'
    },
    { id: 2,
    nome: 'Wanderlei',
    telefones: ['5678-1234'],
    email: 'wanderlei@outlook.com'
    }
];