let filmes = [

    {
    titulo: "HellBoy",
    diretor: "Guilhermo del Toro",
    ano: 2004,
    genero: "Ação"
    }
]

module.exports = {filmes}